"""Export a freshly verified brief with an operator-selected LibreOffice renderer."""

import io
import os
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import BadZipFile

from generate import build_document, parser
from guard import bounded_read, confined, plain_path, publish_new, workspace

PDF_LIMIT = 12 * 1024 * 1024
BLOCKED_KEYS = {
    "/AA", "/AF", "/Annots", "/Collection", "/EF", "/EmbeddedFiles", "/JavaScript",
    "/JS", "/Launch", "/RichMedia", "/XFA", "/AcroForm", "/URI",
}
BLOCKED_TYPES = {
    "/Action", "/EmbeddedFile", "/Filespec", "/FileAttachment", "/RichMedia",
    "/Movie", "/Sound", "/Screen", "/3D", "/Rendition",
}
ACTION_TYPES = {
    "/GoTo", "/GoToR", "/GoToE", "/GoToDp", "/Launch", "/Thread", "/URI", "/Sound",
    "/Movie", "/Hide", "/Named", "/SubmitForm", "/ResetForm", "/ImportData",
    "/JavaScript", "/SetOCGState", "/Rendition", "/Trans", "/GoTo3DView",
}


def check_pdf(data):
    from pypdf import PdfReader
    from pypdf.generic import (
        ArrayObject,
        DictionaryObject,
        FloatObject,
        IndirectObject,
        NameObject,
        NullObject,
        NumberObject,
    )

    if (len(data) > PDF_LIMIT or not data.startswith(b"%PDF-")
            or not data.rstrip().endswith(b"%%EOF")):
        raise ValueError("invalid PDF header, end marker or size")
    reader = PdfReader(io.BytesIO(data), strict=True)
    if reader.is_encrypted or "/Prev" in reader.trailer:
        raise ValueError("encrypted or incremental PDFs are unsupported")
    pending = [reader.trailer]
    for generation, entries in reader.xref.items():
        pending.extend(IndirectObject(obj, generation, reader) for obj in entries if obj)
    pending.extend(IndirectObject(obj, 0, reader) for obj in reader.xref_objStm)
    visited = set()
    nodes = 0
    while pending:
        current = pending.pop()
        nodes += 1
        if nodes > 25000:
            raise ValueError("PDF object graph exceeds limits")
        if isinstance(current, IndirectObject):
            identity = (current.idnum, current.generation)
            if identity in visited:
                continue
            visited.add(identity)
            resolved = current.get_object()
            if resolved is None or isinstance(resolved, NullObject):
                raise ValueError("unresolved PDF reference")
            pending.append(resolved)
        elif isinstance(current, DictionaryObject):
            obj_type = current.get("/Type")
            if (current.keys() & BLOCKED_KEYS
                    or any(key in current and not isinstance(current.raw_get(key), NameObject)
                           for key in ("/Type", "/Subtype", "/S"))
                    or str(obj_type) in BLOCKED_TYPES
                    or str(current.get("/Subtype")) in BLOCKED_TYPES
                    or str(current.get("/S")) in ACTION_TYPES
                    or ("/A" in current and obj_type != "/StructElem")):
                raise ValueError("PDF contains prohibited active content")
            if "/OpenAction" in current:
                # Writer emits a static initial view. Permit only a direct destination.
                view = current.raw_get("/OpenAction")
                if (obj_type != "/Catalog" or not isinstance(view, ArrayObject)
                        or not 2 <= len(view) <= 6 or not isinstance(view[0], IndirectObject)
                        or not isinstance(view[0].get_object(), DictionaryObject)
                        or view[0].get_object().get("/Type") != "/Page"
                        or not isinstance(view[1], NameObject)
                        or view[1] not in {"/XYZ", "/Fit", "/FitH", "/FitV", "/FitR"}
                        or any(not isinstance(arg, (NumberObject, FloatObject, NullObject))
                               for arg in view[2:])):
                    raise ValueError("PDF contains a prohibited open action")
            pending.extend(current.values())
        elif isinstance(current, ArrayObject):
            pending.extend(current)
    if not 1 <= len(reader.pages) <= 100:
        raise ValueError("PDF page count is out of bounds")
    return reader


def renderer_path(raw):
    path = Path(raw)
    name = "soffice.com" if os.name == "nt" else "soffice"
    if path.name.lower() != name:
        raise ValueError("provide the absolute path to the trusted LibreOffice binary")
    parent = workspace(str(path.parent))
    return confined(parent, path.name, path.suffix.lower(), package=True)


def render(office, workspace_dir, document):
    with tempfile.TemporaryDirectory(prefix=".kmd-render-", dir=workspace_dir) as temp:
        scratch = Path(temp)
        docx = scratch / "document.docx"
        docx.write_bytes(document)
        system = {key: os.environ[key] for key in ("SystemRoot", "WINDIR") if key in os.environ}
        paths = (str(Path(system["SystemRoot"]) / "System32") if "SystemRoot" in system
                 else os.defpath)
        environment = dict(system, PATH=paths, HOME=temp, USERPROFILE=temp, APPDATA=temp,
                           LOCALAPPDATA=temp, TEMP=temp, TMP=temp, TMPDIR=temp)
        options = '{"UseTaggedPDF":{"type":"boolean","value":"true"}}'
        subprocess.run(
            [str(office), "-env:UserInstallation=" + (scratch / "profile").as_uri(),
             "--headless", "--nologo", "--nodefault", "--norestore",
             "--convert-to", "pdf:writer_pdf_Export:" + options, "--outdir", temp, str(docx)],
            cwd=scratch, env=environment, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL, shell=False, timeout=60, check=True,
        )
        return bounded_read(scratch / "document.pdf", PDF_LIMIT)


def main():
    args = parser(__doc__)
    args.add_argument("--renderer", required=True, help="absolute operator-approved soffice path")
    options = args.parse_args()
    try:
        import pypdf
        if pypdf.__version__ != "7.2.0":
            raise ValueError("the pinned PDF validator is required")
        root = workspace(options.root)
        brief = confined(root, options.spec, ".json")
        output = confined(root, options.output, ".pdf", new=True)
        spec, document = build_document(brief)
        if "pdf" not in spec["formats"]:
            raise ValueError("the brief does not request PDF")
        renderer = renderer_path(options.renderer)
        plain_path(renderer)
        result = render(renderer, output.parent, document)
        pdf = check_pdf(result)
        publish_new(output, result)
    except (ImportError, ValueError, OSError, ET.ParseError, BadZipFile,
            subprocess.SubprocessError) as exc:
        print(f"BLOCKED: {exc}", file=sys.stderr)
        return 2
    except pypdf.errors.PyPdfError:
        print("BLOCKED: the renderer produced an invalid PDF.", file=sys.stderr)
        return 2
    print(f"PASS: PDF structure verified ({len(pdf.pages)} pages). Visual review is separate.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
