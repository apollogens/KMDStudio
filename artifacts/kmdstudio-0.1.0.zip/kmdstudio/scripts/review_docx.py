"""Check the exact package profile emitted by KMDStudio."""

import io
import re
import stat
import xml.etree.ElementTree as ET
from zipfile import ZIP_DEFLATED, ZIP_STORED, ZipFile

from guard import DOCX_LIMIT, ICON_LIMIT, XML_LIMIT, parse_xml, relative_parts
from ooxml import MAIN_RELS, ROOT_RELS, R, content_types, q, relationships

ROOTS = {
    "word/document.xml": "w:document",
    "word/styles.xml": "w:styles",
    "word/numbering.xml": "w:numbering",
    "word/footer1.xml": "w:ftr",
    "docProps/core.xml": "cp:coreProperties",
}
WORD_TAGS = """
document body p pPr pStyle r rPr t tab br b color keepNext keepLines pageBreakBefore
widowControl pBdr left shd spacing ind outlineLvl jc numPr ilvl numId bookmarkStart
bookmarkEnd sectPr pgSz pgMar hdr ftr headerReference footerReference fldSimple styles
style name basedOn next qFormat rFonts sz szCs lang docDefaults rPrDefault
numbering abstractNum multiLevelType
lvl start numFmt lvlText lvlJc tabs num abstractNumId drawing tbl tblPr tblW tblBorders
bottom insideH tblLayout tblCellMar top right tblGrid gridCol tr trPr cantSplit tblHeader
tc tcPr tcW
"""
DRAWING_TAGS = {
    "wp": "inline extent docPr cNvGraphicFramePr",
    "a": ("graphicFrameLocks graphic graphicData blip stretch fillRect "
          "xfrm off ext prstGeom avLst"),
    "pic": "pic nvPicPr cNvPr cNvPicPr blipFill spPr",
}
ALLOWED_TAGS = {q("w:" + name) for name in WORD_TAGS.split()}
for prefix, names in DRAWING_TAGS.items():
    ALLOWED_TAGS.update(q(prefix + ":" + name) for name in names.split())
ALLOWED_TAGS.update(map(q, ("cp:coreProperties", "dc:title", "dc:description", "dc:language")))
ALLOWED_ATTRS = {q("w:" + key) for key in """
    val type default styleId before after line lineRule left right fill color sz space
    ascii hAnsi eastAsia cs abstractNumId ilvl pos numId id name w h top bottom header
    footer gutter hanging instr
""".split()}
ALLOWED_ATTRS.update("""
    distT distB distL distR cx cy id name descr noChangeAspect uri x y prst
""".split())
ALLOWED_ATTRS.add(q("xml:space"))


def read_archive(data):
    if len(data) > DOCX_LIMIT:
        raise ValueError("DOCX exceeds size limit")
    parts = {}
    with ZipFile(io.BytesIO(data)) as archive:
        entries = archive.infolist()
        if not 8 <= len(entries) <= 21 or archive.comment:
            raise ValueError("DOCX archive profile is invalid")
        if sum(entry.file_size for entry in entries) > DOCX_LIMIT:
            raise ValueError("DOCX expanded size exceeds limit")
        names = set()
        for entry in entries:
            name = entry.orig_filename
            relative_parts(name)
            limit = ICON_LIMIT if name.endswith(".png") else XML_LIMIT
            if (name != entry.filename or "\\" in name or name.casefold() in names
                    or entry.flag_bits & 1 or entry.compress_type not in {ZIP_STORED, ZIP_DEFLATED}
                    or entry.file_size > limit or entry.file_size > 200 * max(entry.compress_size, 1)
                    or entry.extra or entry.comment or stat.S_ISLNK(entry.external_attr >> 16)):
                raise ValueError("unsafe DOCX archive entry")
            names.add(name.casefold())
            with archive.open(entry) as stream:
                content = stream.read(limit + 1)
            if len(content) != entry.file_size:
                raise ValueError("DOCX archive size mismatch")
            parts[name] = content
    return parts


def check_tree(name, root, images):
    fields = 0
    for node in root.iter():
        if node.tag not in ALLOWED_TAGS:
            raise ValueError("unexpected XML element in DOCX")
        for key, value in node.attrib.items():
            if key == q("w:instr"):
                if node.tag != q("w:fldSimple") or name != "word/footer1.xml" or value != "PAGE":
                    raise ValueError("unexpected document field")
                fields += 1
            elif key == q("r:embed"):
                if (node.tag != q("a:blip") or name != "word/document.xml"
                        or value not in images):
                    raise ValueError("unexpected image reference")
            elif key == q("r:id"):
                reference = {"w:headerReference": "rIdHeader", "w:footerReference": "rIdFooter"}
                if name != "word/document.xml" or not any(
                    node.tag == q(tag) and value == rid for tag, rid in reference.items()
                ):
                    raise ValueError("unexpected relationship reference")
            elif key not in ALLOWED_ATTRS:
                raise ValueError("unexpected XML attribute in DOCX")
        if node.tag == q("w:fldSimple") and q("w:instr") not in node.attrib:
            raise ValueError("field instruction is missing")
    if name == "word/footer1.xml" and fields != 1:
        raise ValueError("expected exactly one footer PAGE field")


def _records(root):
    if root.attrib:
        raise ValueError("package metadata contains unexpected attributes")
    if any(len(child) or child.text for child in root):
        raise ValueError("unexpected nested package metadata")
    return sorted((node.tag, sorted(node.attrib.items())) for node in root)


def check_docx(data, assets):
    parts = read_archive(data)
    image_parts = sorted(
        (name for name in parts if re.fullmatch(r"word/media/image[1-9][0-9]?\.png", name)),
        key=lambda name: int(name.split("image")[-1][:-4]),
    )
    roots = dict(ROOTS)
    rels = list(MAIN_RELS)
    has_header = "word/header1.xml" in parts
    if has_header:
        roots["word/header1.xml"] = "w:hdr"
        rels.append(("rIdHeader", R + "/header", "header1.xml"))
    image_ids = set()
    for index, name in enumerate(image_parts, 1):
        if name != f"word/media/image{index}.png" or parts[name] not in assets.values():
            raise ValueError("image is outside the verified library")
        identity = f"rIdImage{index}"
        rels.append((identity, R + "/image", f"media/image{index}.png"))
        image_ids.add(identity)
    metadata = {
        "[Content_Types].xml": content_types(has_header, bool(image_parts)),
        "_rels/.rels": relationships(ROOT_RELS),
        "word/_rels/document.xml.rels": relationships(rels),
    }
    if set(parts) != set(roots) | set(metadata) | set(image_parts):
        raise ValueError("unexpected or missing DOCX part")
    for name, generated in metadata.items():
        root = parse_xml(parts[name])
        expected = parse_xml(ET.tostring(generated, encoding="utf-8"))
        if root.tag != expected.tag or _records(root) != _records(expected):
            raise ValueError("unexpected content types or relationships")
    trees = {}
    for name, tag in roots.items():
        root = parse_xml(parts[name])
        if root.tag != q(tag):
            raise ValueError("unexpected root in DOCX XML part")
        check_tree(name, root, image_ids)
        trees[name] = root
    return trees["word/document.xml"]


def text_paragraphs(document):
    result = []
    for para in document.iter(q("w:p")):
        style = para.find(f"{q('w:pPr')}/{q('w:pStyle')}")
        if style is not None and style.get(q("w:val")) == "DiagramArrow":
            continue
        pieces = []
        for node in para.iter():
            if node.tag == q("w:t"):
                pieces.append(node.text or "")
            elif node.tag == q("w:tab"):
                pieces.append("\t")
            elif node.tag == q("w:br") and q("w:type") not in node.attrib:
                pieces.append("\n")
        if pieces:
            result.append("".join(pieces))
    return result


def check_content(document, spec):
    headline = [spec["title"]]
    if "subtitle" in spec:
        headline.append(spec["subtitle"])
    expected = [] if spec["blocks"][0]["kind"] == "cover" else list(headline)
    for block in spec["blocks"]:
        match block["kind"]:
            case "cover":
                expected.extend([block["label"], *headline, block["lead"]])
                if "caption" in block:
                    expected.append(block["caption"])
            case "heading" | "paragraph":
                expected.append(block["text"])
            case "list":
                expected.extend(block["items"])
            case "callout":
                expected.extend([block["title"], block["text"]])
            case "code" | "table":
                if "caption" in block:
                    expected.append(block["caption"])
                if block["kind"] == "code":
                    expected.append(block["text"])
                else:
                    expected.extend(block["headers"])
                    for row in block["rows"]:
                        expected.extend(row)
            case "diagram":
                expected.append(block["caption"])
                for step in block["steps"]:
                    expected.extend([step["label"], step["detail"]])
            case "figure":
                expected.append(block["caption"])
            case "exercise":
                expected.extend([block["title"], block["intro"], *block["steps"]])
                if "check" in block:
                    expected.append(block["check"])
    bookmarks = [node.get(q("w:name")) for node in document.iter(q("w:bookmarkStart"))]
    expected_names = ["kmd_" + block["id"].replace("-", "_") for block in spec["blocks"]]
    if text_paragraphs(document) != expected or bookmarks != expected_names:
        raise ValueError("editable content or block identifiers differ from the brief")
