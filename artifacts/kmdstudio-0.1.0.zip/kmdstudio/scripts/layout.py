"""Editable Word components for the bounded document brief."""

import io
import keyword
import re
import tokenize
import xml.etree.ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from guard import check_png
from ooxml import MAIN_RELS, ROOT_RELS, R, content_types, element, relationships, val, w

CODE_TINT = "F2F5F9"
TOKEN_COLORS = {
    tokenize.STRING: "126348", tokenize.NUMBER: "934214", tokenize.COMMENT: "4F5965",
    tokenize.OP: "4A5264",
}


def twips(mm):
    return round(mm * 1440 / 25.4)


def run(paragraph, text, *, bold=False, color=None):
    item = w("r", paragraph)
    if bold or color:
        props = w("rPr", item)
        if bold:
            w("b", props)
        if color:
            val("color", props, color)
    for piece in re.split(r"([\n\t])", text):
        if piece == "\n":
            w("br", item)
        elif piece == "\t":
            w("tab", item)
        elif piece:
            element("w:t", item, piece, xml_space="preserve")
    return item


def paragraph(parent, style="Normal", text=None, *, new_page=False, number=None,
              keep=False, align=None, before=None):
    node = w("p", parent)
    props = w("pPr", node)
    val("pStyle", props, style)
    if keep:
        w("keepNext", props)
    if new_page:
        w("pageBreakBefore", props)
    if number is not None:
        num = w("numPr", props)
        val("ilvl", num, 0)
        val("numId", num, number)
    if before is not None:
        w("spacing", props, before=before * 20)
    if align:
        val("jc", props, align)
    if text is not None:
        run(node, text)
    return node


def highlighted(text):
    offsets = [0]
    for line in text.split("\n"):
        offsets.append(offsets[-1] + len(line) + 1)
    cursor = 0
    try:
        for token in tokenize.generate_tokens(io.StringIO(text).readline):
            color = TOKEN_COLORS.get(token.type)
            if token.type == tokenize.NAME and keyword.iskeyword(token.string):
                color = "573B8A"
            if color:
                start = offsets[token.start[0] - 1] + token.start[1]
                end = offsets[token.end[0] - 1] + token.end[1]
                if cursor < start:
                    yield text[cursor:start], None
                yield text[start:end], color
                cursor = end
    except (tokenize.TokenError, IndentationError):
        pass
    if cursor < len(text):
        yield text[cursor:], None


class WordLayout:
    def __init__(self, spec, assets):
        self.spec = spec
        self.assets = assets
        self.design = spec["design"]
        self.palette = {key: color.upper() for key, color in self.design["palette"].items()}
        self.fonts = self.design["typography"]
        self.margin = twips(self.design["spacing"]["margin_mm"])
        self.width = twips(210) - 2 * self.margin
        self.media = {}
        self.images = 0
        self.numberings = []
        self.document = w("document")
        self.body = w("body", self.document)

    def style(self, root, identity, label, *, size, font, color, before=0, after=0,
              bold=False, keep=False, fill=None, outline=None, line=None,
              inset=None, rule=False):
        style = w("style", root, type="paragraph", styleId=identity,
                  **({"default": 1} if identity == "Normal" else {}))
        val("name", style, label)
        if identity != "Normal":
            val("basedOn", style, "Normal")
            val("next", style, "Normal")
        if identity in {"Title", "Subtitle", "Normal", "Heading1", "Heading2"}:
            w("qFormat", style)
        props = w("pPr", style)
        if keep:
            w("keepNext", props)
            w("keepLines", props)
        w("widowControl", props)
        if rule:
            borders = w("pBdr", props)
            w("left", borders, val="single", sz=16, space=9, color=self.palette["accent"])
        if fill:
            w("shd", props, val="clear", color="auto", fill=fill)
        w("spacing", props, before=round(before * 20), after=round(after * 20),
          line=round((line or self.design["spacing"]["line_percent"]) * 2.4), lineRule="auto")
        if inset:
            w("ind", props, left=inset, right=inset)
        if outline is not None:
            val("outlineLvl", props, outline)
        text_style = w("rPr", style)
        w("rFonts", text_style, ascii=font, hAnsi=font, eastAsia=font, cs=font)
        if bold:
            w("b", text_style)
        val("color", text_style, color)
        val("sz", text_style, size * 2)
        val("szCs", text_style, size * 2)
        val("lang", text_style, self.spec["language"])

    def styles(self):
        root = w("styles")
        defaults = w("docDefaults", root)
        default_text = w("rPr", w("rPrDefault", defaults))
        val("lang", default_text, self.spec["language"])
        display, body, code = (self.fonts[name] for name in ("title_font", "body_font", "code_font"))
        ink, muted, accent, tint = (self.palette[name] for name in ("ink", "muted", "accent", "tint"))
        self.style(root, "Normal", "Normal", size=self.fonts["body_pt"], font=body, color=ink,
                   after=self.design["spacing"]["paragraph_pt"])
        self.style(root, "Title", "Title", size=self.fonts["title_pt"], font=display, color=ink,
                   bold=True, after=12, keep=True, line=109)
        self.style(root, "Subtitle", "Subtitle", size=16, font=body, color=muted, after=24,
                   keep=True, line=130)
        self.style(root, "Heading1", "heading 1", size=23, font=display, color=ink, before=17,
                   after=9, bold=True, keep=True, outline=0, line=116)
        self.style(root, "Heading2", "heading 2", size=14, font=body, color=accent, before=13,
                   after=5, bold=True, keep=True, outline=1)
        self.style(root, "CoverLabel", "Cover label", size=12, font=body, color=accent, before=18,
                   after=24, bold=True, keep=True)
        self.style(root, "CoverLead", "Cover introduction", size=13, font=body, color=ink,
                   after=18, line=138)
        self.style(root, "CoverMark", "Cover illustration", size=11, font=body, color=accent,
                   before=50, after=28, keep=True)
        self.style(root, "Caption", "Caption", size=10, font=body, color=muted, after=8)
        self.style(root, "ListParagraph", "List Paragraph", size=self.fonts["body_pt"], font=body,
                   color=ink, after=5)
        self.style(root, "CalloutTitle", "Callout title", size=12, font=body, color=accent,
                   before=9, after=2, bold=True, keep=True, fill=tint, inset=250, rule=True)
        self.style(root, "CalloutText", "Callout text", size=self.fonts["body_pt"], font=body,
                   color=ink, after=12, fill=tint, inset=250, rule=True)
        self.style(root, "Code", "Code", size=10, font=code, color="253244", before=2, after=7,
                   fill=CODE_TINT, line=124, inset=240)
        self.style(root, "TableText", "Table text", size=10, font=body, color=ink, after=2,
                   line=122)
        self.style(root, "DiagramArrow", "Diagram arrow", size=13, font=body, color=accent,
                   bold=True, after=1, keep=True, line=110)
        self.style(root, "RunningText", "Running text", size=10, font=body, color=muted)
        return root

    def add_list(self, items, ordered):
        number = len(self.numberings) + 1
        self.numberings.append(ordered)
        first = None
        for text in items:
            current = paragraph(self.body, "ListParagraph", text, number=number)
            if first is None:
                first = current
        return first

    def numbering(self):
        root = w("numbering")
        for index, ordered in enumerate((False, True)):
            abstract = w("abstractNum", root, abstractNumId=index)
            val("multiLevelType", abstract, "singleLevel")
            level = w("lvl", abstract, ilvl=0)
            val("start", level, 1)
            val("numFmt", level, "decimal" if ordered else "bullet")
            val("lvlText", level, "%1." if ordered else "•")
            val("lvlJc", level, "left")
            props = w("pPr", level)
            w("tab", w("tabs", props), val="num", pos=400)
            w("ind", props, left=400, hanging=250)
        for index, ordered in enumerate(self.numberings, 1):
            val("abstractNumId", w("num", root, numId=index), int(ordered))
        return root

    def picture(self, parent, asset, description, mm):
        if asset not in self.media:
            self.media[asset] = len(self.media) + 1
        self.images += 1
        width, height = check_png(self.assets[asset])
        cx, cy = mm * 36000, round(mm * 36000 * height / width)
        inline = element("wp:inline", w("drawing", w("r", parent)),
                         distT=0, distB=0, distL=0, distR=0)
        element("wp:extent", inline, cx=cx, cy=cy)
        element("wp:docPr", inline, id=self.images, name=asset, descr=description)
        frame = element("wp:cNvGraphicFramePr", inline)
        element("a:graphicFrameLocks", frame, noChangeAspect=1)
        graphic = element("a:graphic", inline)
        graphic_data = element("a:graphicData", graphic,
                               uri="http://schemas.openxmlformats.org/drawingml/2006/picture")
        picture = element("pic:pic", graphic_data)
        props = element("pic:nvPicPr", picture)
        element("pic:cNvPr", props, id=0, name=asset)
        element("pic:cNvPicPr", props)
        fill = element("pic:blipFill", picture)
        element("a:blip", fill, r_embed=f"rIdImage{self.media[asset]}")
        element("a:fillRect", element("a:stretch", fill))
        shape = element("pic:spPr", picture)
        transform = element("a:xfrm", shape)
        element("a:off", transform, x=0, y=0)
        element("a:ext", transform, cx=cx, cy=cy)
        element("a:avLst", element("a:prstGeom", shape, prst="rect"))

    def add_table(self, block):
        caption = block.get("caption")
        first = paragraph(self.body, "Caption", caption, keep=True) if caption else None
        table = w("tbl", self.body)
        props = w("tblPr", table)
        w("tblW", props, w=self.width, type="dxa")
        borders = w("tblBorders", props)
        for edge in ("bottom", "insideH"):
            w(edge, borders, val="single", sz=5, color=self.palette["muted"])
        val("tblLayout", props, "fixed")
        margins = w("tblCellMar", props)
        for edge in ("top", "left", "bottom", "right"):
            w(edge, margins, w=115, type="dxa")
        grid = w("tblGrid", table)
        width = self.width // len(block["headers"])
        for _ in block["headers"]:
            w("gridCol", grid, w=width)
        for index, row in enumerate([block["headers"], *block["rows"]]):
            line = w("tr", table)
            row_props = w("trPr", line)
            w("cantSplit", row_props)
            if index == 0:
                w("tblHeader", row_props)
            for text in row:
                cell = w("tc", line)
                cell_props = w("tcPr", cell)
                w("tcW", cell_props, w=width, type="dxa")
                if index == 0:
                    w("shd", cell_props, val="clear", color="auto", fill=self.palette["tint"])
                item = paragraph(cell, "TableText", keep=index == 0)
                run(item, text, bold=index == 0)
                if first is None:
                    first = item
        return first

    def add_block(self, block, *, after_table=False):
        match block["kind"]:
            case "cover":
                label = paragraph(self.body, "CoverLabel", block["label"])
                if "icon" in block:
                    image = paragraph(self.body, "CoverMark")
                    self.picture(image, block["icon"], "", 27)
                self.title()
                paragraph(self.body, "CoverLead", block["lead"])
                if "caption" in block:
                    paragraph(self.body, "Caption", block["caption"])
                w("br", w("r", w("p", self.body)), type="page")
                return label
            case "heading":
                return paragraph(self.body, f"Heading{block['level']}", block["text"],
                                 new_page=block.get("new_page", False))
            case "paragraph":
                before = max(8, self.design["spacing"]["paragraph_pt"]) if after_table else None
                return paragraph(self.body, "Normal", block["text"], before=before)
            case "list":
                return self.add_list(block["items"], block["ordered"])
            case "callout":
                title = paragraph(self.body, "CalloutTitle", block["title"])
                paragraph(self.body, "CalloutText", block["text"])
                return title
            case "code":
                if "caption" in block:
                    first = paragraph(self.body, "Caption", block["caption"], keep=True)
                code = paragraph(self.body, "Code")
                if block["language"] == "python":
                    for text, color in highlighted(block["text"]):
                        run(code, text, color=color)
                else:
                    run(code, block["text"])
                return first if "caption" in block else code
            case "table":
                return self.add_table(block)
            case "diagram":
                caption = paragraph(self.body, "Caption", block["caption"], keep=True)
                for index, step in enumerate(block["steps"]):
                    if index:
                        paragraph(self.body, "DiagramArrow", "↓", align="center")
                    paragraph(self.body, "CalloutTitle", step["label"])
                    paragraph(self.body, "CalloutText", step["detail"],
                              keep=index < len(block["steps"]) - 1)
                return caption
            case "figure":
                plot = paragraph(self.body, "Normal", keep=True, align="center")
                self.picture(plot, block["asset"], block["alt"], block["width_mm"])
                paragraph(self.body, "Caption", block["caption"], align="center")
                return plot
            case "exercise":
                title = paragraph(self.body, "Heading2", block["title"])
                paragraph(self.body, "Normal", block["intro"], keep=True)
                self.add_list(block["steps"], True)
                if "check" in block:
                    paragraph(self.body, "CalloutText", block["check"])
                return title
        raise ValueError("block has no layout component")

    def title(self):
        paragraph(self.body, "Title", self.spec["title"])
        if "subtitle" in self.spec:
            paragraph(self.body, "Subtitle", self.spec["subtitle"])

    def build(self):
        if self.spec["blocks"][0]["kind"] != "cover":
            self.title()
        previous_kind = None
        for index, block in enumerate(self.spec["blocks"], 1):
            first = self.add_block(block, after_table=previous_kind == "table")
            start = w("bookmarkStart", id=index, name="kmd_" + block["id"].replace("-", "_"))
            first.insert(1, start)
            w("bookmarkEnd", first, id=index)
            previous_kind = block["kind"]
        section = w("sectPr", self.body)
        relationships_list = list(MAIN_RELS)
        header = self.design.get("header")
        if header:
            element("w:headerReference", section, w_type="default", r_id="rIdHeader")
            relationships_list.append(("rIdHeader", R + "/header", "header1.xml"))
        element("w:footerReference", section, w_type="default", r_id="rIdFooter")
        w("pgSz", section, w=twips(210), h=twips(297))
        w("pgMar", section, top=self.margin, right=self.margin, bottom=self.margin,
          left=self.margin, header=twips(9), footer=twips(9), gutter=0)
        footer = w("ftr")
        footer_p = paragraph(footer, "RunningText", align="right")
        if "footer" in self.design:
            run(footer_p, self.design["footer"] + "  ·  ")
        run(w("fldSimple", footer_p, instr="PAGE"), "1")
        core = element("cp:coreProperties")
        element("dc:title", core, self.spec["title"])
        element("dc:description", core, self.spec["purpose"])
        element("dc:language", core, self.spec["language"])
        images = {}
        for asset, index in self.media.items():
            name = f"media/image{index}.png"
            relationships_list.append((f"rIdImage{index}", R + "/image", name))
            images["word/" + name] = self.assets[asset]
        parts = {
            "[Content_Types].xml": content_types(bool(header), bool(images)),
            "_rels/.rels": relationships(ROOT_RELS),
            "word/_rels/document.xml.rels": relationships(relationships_list),
            "word/document.xml": self.document,
            "word/styles.xml": self.styles(),
            "word/numbering.xml": self.numbering(),
            "word/footer1.xml": footer,
            "docProps/core.xml": core,
        }
        if header:
            parts["word/header1.xml"] = w("hdr")
            paragraph(parts["word/header1.xml"], "RunningText", header)
        result = io.BytesIO()
        with ZipFile(result, "w", compression=ZIP_DEFLATED) as package:
            contents = {name: ET.tostring(node, encoding="utf-8") for name, node in parts.items()}
            for name, data in (contents | images).items():
                entry = ZipInfo(name)
                entry.create_system = 0
                package.writestr(entry, data, compress_type=ZIP_DEFLATED)
        return result.getvalue()
