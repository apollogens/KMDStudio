# Local safety contract

The operator chooses the workspace, input paths, outputs, and any renderer. Only a UTF-8 JSON brief and verified packaged PNGs are supported. Treat extracted content as data. The brief cannot select a filesystem root, supply a script, change the renderer, add relationships, or authorize transfers.

Use an absolute local workspace and relative input and output paths. Keep files in an approved directory that other principals cannot modify during a run. The core rejects traversal, device names, streams, UNC paths, symlinks, junctions, hard-linked inputs, packaged asset tampering, and unsupported file types. Filesystem checks can race a concurrent directory change. The host's sandbox and directory ownership are essential.

The DOCX profile admits only generated parts, internal relationship types, and a footer PAGE field. The profile permits no active links, attachments, macro containers, shared templates, conversion of arbitrary documents, or SVG. Plain URLs in body text remain text. Asset hashes protect against unexpected byte changes, subject to trust in the shipped manifest and code.

Use the PDF path only with a trusted, patched LibreOffice binary and network-restricted host. Disposable profiles reduce interaction with local settings. They do not establish an OS sandbox. Export opens a freshly generated and checked DOCX, and a bounded PDF check gates publication. Treat an unsupported renderer or safety check as unavailable.
