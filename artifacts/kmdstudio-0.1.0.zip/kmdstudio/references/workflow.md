# Brief and local workflow

The [JSON Schema](../schemas/document.schema.json) describes the authoring shape. The Python validator enforces the same structural subset and checks cross-field invariants. A generator run uses a trusted project directory and distinct relative paths under it. Create the output parent first. The generator refuses overwrites.

```powershell
python -E -s -B skills/kmdstudio/scripts/generate.py --root (Get-Location).Path --spec examples/python-oop-lecture.json --output artifacts/draft.docx
python -E -s -B skills/kmdstudio/scripts/render_pdf.py --root (Get-Location).Path --spec examples/python-oop-lecture.json --output artifacts/draft.pdf --renderer 'C:/trusted/LibreOffice/program/soffice.com'
```

The PDF command requires [the pinned optional package](../requirements-pdf.lock) and host containment. It builds and verifies its input again in an isolated temporary working directory. For ordinary generation, invoke only the format commands the user requested. A visual review and a user-facing publication decision remain separate from either command's structural result.

## Brief fields

- `purpose`, `audience`, `language`, `title`, and optional `subtitle` describe the assignment. A language such as `ru-RU` also sets the Word proofing language.
- `design` contains the palette, font roles, body and title sizes, margins, paragraph spacing, and line height. The direction records the art direction decision. The tokens control rendering. Optional `header` and `footer` set running text.
- `formats` lists DOCX, PDF, or both in lowercase. `acceptance.required_ids` binds source commitments to `blocks`. Give each block a different lowercase ID. Use acceptance criteria for the page count, content, readability, and audience needs that a reviewer can observe.
- Blocks appear in reading order. A cover, if used, comes first. Use level 1 and 2 headings in order. A heading can start a new page. Let content flow naturally unless page boundaries serve the editorial plan.
- `paragraph`, `list`, `callout`, `code`, `table`, `diagram`, `figure`, and `exercise` map to native document components. Use Python or plain-text code, captioned tables and figures, and short text for the stages of a process diagram. Figure content uses a manifest asset ID, a meaningful alternative description, and a caption. A cover icon is decorative.

Treat accepted source text as ready for typesetting. For corrections, save a new version of the brief and generate to a new filename. Verify the newly generated artifact before choosing a delivery file.
