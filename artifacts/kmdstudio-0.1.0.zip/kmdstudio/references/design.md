# Art direction for editable documents

Choose a reading sequence before placing visual elements. Give each section one clear purpose. Establish hierarchy through type weight, position, and spacing. Use color to guide attention and keep cues understandable in grayscale.

For lectures and workbooks, connect a definition to a worked example and a practice task. Introduce information in reading order. Use visible labels and captions to connect a diagram with its explanation. For reports, put the decision or conclusion near the top, use tables for comparisons, and keep running text compact. For other directions, tune the tokens and block mix to the audience and reference.

Use semantic heading levels, real numbered and bulleted lists, native table headers, and paragraphs for body text. Keep technical labels and source code editable. Limit line lengths and table columns to the page width. Test tables with longer values and avoid headings alone at the bottom of pages. The brief enforces 4.5:1 contrast for text roles on white and tint.

For Windows, Arial, Georgia, and Consolas are practical defaults with Cyrillic coverage where installed. Use Arial for a sans fallback, Georgia for a serif fallback, and Courier New or Consolas for code. Select a fallback in the brief if the target renderer lacks the selected font. The skill ships no fonts, so page breaks and glyph metrics may vary across Word and Writer. Check the actual output on the delivery renderer.

Use a bundled icon when its meaning supports the reader. Give informative figures and diagrams text that conveys the same conclusion. Use host-native generation only for artistic illustrations that the user authorizes and the available input workflow can safely handle.
